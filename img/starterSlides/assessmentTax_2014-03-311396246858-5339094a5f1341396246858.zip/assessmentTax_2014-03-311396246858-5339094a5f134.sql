-- Developed By Ruwan jayawardena

-- Dumping tables for database: 


SET FOREIGN_KEY_CHECKS=0; 


-- Dumping structure for table: `at_ward`

DROP TABLE IF EXISTS `at_ward`;
-- Error in getting create of `at_ward`

-- Dumping data for table: at_ward

INSERT INTO `at_ward` VALUES('1', 'Default');


SET FOREIGN_KEY_CHECKS=1; 

